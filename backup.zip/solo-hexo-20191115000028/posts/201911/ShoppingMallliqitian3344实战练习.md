title: ShoppingMall-liqitian3344实战练习
date: '2019-11-14 09:44:51'
updated: '2019-11-14 15:25:40'
tags: [待分类]
permalink: /articles/2019/11/14/1573695891267.html
---
项目地址：[ShoppingMall-liqitian3344](https://gitee.com/liqitian3344/ShoppingMall-liqitian3344 "ShoppingMall-liqitian3344")
### 准备redis环境
```
#跑了centos容器，预先开启7001-7006端口，不挂载任何目录
docker run --name redis-cluster-liqitian3344 --privileged=true -dit -p 7001:7001 -p 7002:7002 -p 7003:7003 -p 7004:7004 -p 7005:7005 -p 7006:7006 centos:latest

#进入容器中
docker exec -it redis-cluster-liqitian3344 bash

$ cd /root
$ wget http://download.redis.io/releases/redis-5.0.6.tar.gz
$ tar xzf redis-5.0.6.tar.gz
$ cd redis-5.0.6
$ make
```
####  准备集群节点
```
$ mkdir -p redis-cluster/redis-01
#把/root/redis-5.0.6/src/下的`redis-cli`,`redis-server`和/root/redis-5.0.6/redis.conf复制到redis-01下
$ cp /root/redis-5.0.6/src/redis-cli redis-01/
$ cp /root/redis-5.0.6/src/redis-server redis-01/
#简单修改redis-01/redis.conf
  1. 注释掉 `bind 127.0.0.1`
  2. `port`改为7001
  3. `cluster-enabled yes` 
  4. `protected-mode no`
  5. `daemonize yes`
# 将redis-01文件夹复制6份，依次为redis-02到redis-06，再依次修改各文件夹下redis.conf port为 7002-7006
```
创建启动脚本start-all.sh如下
```
cd redis-01 
./redis-server redis.conf &

cd ../redis-02 
./redis-server redis.conf &

cd ../redis-03 
./redis-server redis.conf &

cd ../redis-04 
./redis-server redis.conf &

cd ../redis-05
./redis-server redis.conf &

cd ../redis-06
./redis-server redis.conf 
```
启动集群：
`redis-cli --cluster create 127.0.0.1:7001 127.0.0.1:7002 127.0.0.1:7003 127.0.0.1:7004 127.0.0.1:7005 127.0.0.1:7006 --cluster-replicas 1`

创建关闭脚本stop-all.sh如下

```
cd redis-01 
./redis-cli -p 7001 shutdown &

cd ../redis-02 
./redis-cli -p 7002 shutdown &

cd ../redis-03 
./redis-cli -p 7003 shutdown & 

cd ../redis-04 
./redis-cli -p 7004 shutdown &

cd ../redis-05
./redis-cli -p 7005 shutdown &

cd ../redis-04 
./redis-cli -p 7006 shutdown 
```
连接任意节点:   `redis-cli -c -p 7006`查看集群信息
![image.png](https://img.hacpai.com/file/2019/11/image-2d0e221d.png)

再看下现在的主从状态
![image.png](https://img.hacpai.com/file/2019/11/image-7734aac7.png)
很明显可以看到主从状态，根据slots也可判别。
待续~
