title: Mysql Test Data InsertUtil
date: '2019-11-10 17:29:04'
updated: '2019-11-10 17:29:04'
tags: [MysqlInsertUtil]
permalink: /articles/2019/11/10/1573378143990.html
---
😔存储过程不会写放在这里备用~~~
```

DROP PROCEDURE IF EXISTS per2;
create procedure per2()
begin
 
declare num int;
declare theme_id int;
declare alternate_field int;
declare url_ varchar(100) default 'http://xxxx';
 
set num=1;
set theme_id=1401;
set alternate_field=1101;
 
while num < 10 do
	
	INSERT INTO `test`.`users`(`id_no`, `name`, `mobile`, `age`, `address`) VALUES (CONCAT('1231233',theme_id), 'name', 'phone_number', 16, 'address');

	set num=num+1;
	set theme_id=theme_id+1;
 
end while;
end;
 
call per2();
```
