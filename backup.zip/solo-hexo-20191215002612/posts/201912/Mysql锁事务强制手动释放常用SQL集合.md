title: Mysql 锁、事务强制手动释放（常用SQL集合）
date: '2019-12-13 16:49:36'
updated: '2019-12-13 17:21:44'
tags: [tool]
permalink: /articles/2019/12/13/1576226976264.html
---
1. 查看数据库当前的进程，看一下有无正在执行的慢SQL记录线程。

```
mysql> show  processlist;
```
2. 查看当前的事务

当前运行的所有事务

```
mysql> SELECT * FROM information_schema.INNODB_TRX;
```
当前出现的锁

```
mysql> SELECT * FROM performance_schema.data_locks\G
```
锁等待的对应关系

```
mysql> SELECT * FROM performance_schema.data_lock_waits\G
```
解释：看事务表INNODB_TRX，里面是否有正在锁定的事务线程，看看ID是否在show processlist里面的sleep线程中，如果是，就证明这个sleep的线程事务一直没有commit或者rollback而是卡住了，我们需要手动kill掉。

搜索的结果是在事务表发现了很多任务，这时候最好都kill掉。

3、批量删除事务表中的事务

我这里用的方法是：通过information_schema.processlist表中的连接信息生成需要处理掉的MySQL连接的语句临时文件，然后执行临时文件中生成的指令。

```
mysql> select concat('KILL ',id,';') from information_schema.processlist p inner
 join information_schema.INNODB_TRX x on p.id=x.trx_mysql_thread_id where db='db_name';

+------------------------+
| concat('KILL ',id,';') |
+------------------------+
| KILL 26216;           |
+------------------------+

 3 rows in set  
```

kill掉以后再执行SELECT * FROM information_schema.INNODB_TRX; 就是空了。

下面是常用到的SQL，记录下来便于使用

1. 按客户端 IP 分组，看哪个客户端的链接数最多

```
select client_ip,count(client_ip) as client_num from (select substring_index(host,':' ,1) as client_ip from processlist ) as connect_info group by client_ip order by client_num desc;
```

2. 查看正在执行的线程，并按 Time 倒排序，看看有没有执行时间特别长的线程

```
select * from information_schema.processlist where Command != 'Sleep' order by Time desc;
```

3. 找出所有执行时间超过 5 分钟的线程，拼凑出 kill 语句，方便后面查杀
```
select concat('kill ', id, ';') from information_schema.processlist where Command != 'Sleep' and Time > 300 order by Time desc;
```


4. 查看mysql 特定表所有外键约束
```
select
TABLE_NAME,COLUMN_NAME,CONSTRAINT_NAME, REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME
from INFORMATION_SCHEMA.KEY_COLUMN_USAGE
where CONSTRAINT_SCHEMA ='db_name' AND
REFERENCED_TABLE_NAME = 'table_name';
```
5. 查看MySQL服务器配置信息 

```
#查看系统运行的实时状态，便于dba查看mysql当前运行的状态，做出相应优化，动态的，不可认为修改，只能系统自动update。
show variables; 
 ```

  
6.  查看MySQL服务器运行的各种状态值 
```
#查看系统参数，系统默认设置或者dba调整优化后的参数，静态的。可以通过set或者修改my.cnf配置文件修改
show global status;
```
