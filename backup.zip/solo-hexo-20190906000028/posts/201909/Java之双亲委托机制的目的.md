title: Java之双亲委托机制的目的
date: '2019-09-02 15:42:14'
updated: '2019-09-03 10:15:45'
tags: [java]
permalink: /articles/2019/09/02/1567410134330.html
---
双亲委派机制：

当一个Hello.class这样的文件要被加载时（不考虑我们自定义类加载器），首先会在AppClassLoader中检查是否加载过，如果有那就无需再加载了。如果没有，那么会拿到父加载器，然后调用父加载器的loadClass方法。父类中同理会先检查自己是否已经加载过，如果没有再往上。注意这个过程，直到到达Bootstrap classLoader之前，都是没有哪个加载器自己选择加载的。如果父加载器无法加载，会下沉到子加载器去加载，一直到最底层，如果没有任何加载器能加载，就会抛出**ClassNotFoundException**。

这里简要描述下java的三种类加载器

1 <font color=red>引导类加载器</font>(**Bootstrap classLoader**)

主要负责加载jvm自身所需要的类，该加载器由C++实现，意必由于虚拟机是按照文件名识别加载jar包  的，如rt.jar，如果文件名不被虚拟机识别，即使把jar包丢到lib目录下也是没有作用的(出于安全考虑， Bootstrap启动类加载器只加载包名为java、javax、sun等开头的类)。

2  <font color=red>拓展类加载器</font>(**ExtClassLoader**)

扩展类加载器是指Sun公司(已被Oracle收购)实现的sun.misc.Launcher$ExtClassLoader类，由Java语言  实现的，是Launcher的静态内部类，它负责加载<JAVA_HOME>/lib/ext目录下或者由系统变量-  Djava.ext.dir指定位路径中的类库，开发者可以直接使用标准扩展类加载器。

3 <font color=red>系统类加载器</font>(**AppClassLoader**)

也称应用程序加载器是指 Sun公司实现的sun.misc.Launcher$AppClassLoader。它负责加载系统类路径  java -classpath或-D java.class.path指定路径下的类库，也就是我们经常用到的classpath路径，开发者  可以直接使用系统类加载器，一般情况下该类加载是程序中默认的类加载器.

  

下面用个面试题记录这个问题，能不能自己手写个类是 java.lang.System？

：一般情况下是不能为了不让我们写System类，类加载采用委托机制，这样可以保证爸爸们优先，爸爸们能找  到的类，儿子就没有机会加载。而System类是Bootstrap加载器加载的，就算自己重写，也总是使用 Java系统提供的System，自己写的System类根本没有机会得到加载。

 但是，我们可以自己定义一个类加载器来达到这个目的。
首先介绍自定义类的应用场景：

（1）<font color=#008000>加密</font>：Java代码可以轻易的被反编译，如果你需要把自己的代码进行加密以防止反编译，可以先将编译后的代码用某种加密算法加密，类加密后就不能再用Java的ClassLoader去加载类了，这时就需要自定义ClassLoader在加载类的时候先解密类，然后再加载。

（2）<font color=#008000>从非标准的来源加载代码</font>：如果你的字节码是放在数据库、甚至是在云端，就可以自定义类加载器，从指定的来源加载类。

（3）以上两种情况在实际中的综合运用：比如你的应用需要通过网络来传输 Java 类的字节码，为了安全性，这些字节码经过了加密处理。这个时候你就需要自定义类加载器来从某个网络地址上读取加密后的字节代码，接着进行解密和验证，最后定义出在Java虚拟机中运行的类。
```
 protected Class<?> loadClass(String name, boolean resolve)
        throws ClassNotFoundException
    {
        synchronized (getClassLoadingLock(name)) {
            // First, check if the class has already been loaded
            Class<?> c = findLoadedClass(name);
            if (c == null) {
                long t0 = System.nanoTime();
                try {
                    if (parent != null) {
                        c = parent.loadClass(name, false);
                    } else {
                        c = findBootstrapClassOrNull(name);
                    }
                } catch (ClassNotFoundException e) {
                    // ClassNotFoundException thrown if class not found
                    // from the non-null parent class loader
                }

                if (c == null) {
                    // If still not found, then invoke findClass in order
                    // to find the class.
                    long t1 = System.nanoTime();
                    c = findClass(name);

                    // this is the defining class loader; record the stats
                    sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                    sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                    sun.misc.PerfCounter.getFindClasses().increment();
                }
            }
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }
```
**双亲委派模型的工作过程如下：**

（1）<font color=Blue>当前类加载器从自己已经加载的类中查询是否此类已经加载，如果已经加载则直接返回原来已经加载的类。</font>

（2）<font color=Blue>如果没有找到，就去委托父类加载器去加载（如代码c = parent.loadClass(name, false)所示）。父类加载器也会采用同样的策略，查看自己已经加载过的类中是否包含这个类，有就返回，没有就委托父类的父类去加载，一直到启动类加载器。因为如果父加载器为空了，就代表使用启动类加载器作为父加载器去加载。</font>

（3）<font color=Blue>如果启动类加载器加载失败（例如在$JAVA_HOME/jre/lib里未查找到该class），会使用拓展类加载器来尝试加载，继续失败则会使用AppClassLoader来加载，继续失败则会抛出一个异常ClassNotFoundException，然后再调用当前加载器的findClass()方法进行加载。</font>

 **比如要加载自己写的String类**，自定义一个String类放在某路径下，自定义一个类加载器继承ClassLoader类，并实现findClass方法（在自己的路径下去取String类）。重写loadClass方法让它不走双亲委派，这样他就会直接调用findClass加载自己的String类了。

**双亲委派模型的好处：**

（1）<font color=red>主要是为了安全性，避免用户自己编写的类动态替换 Java的一些核心类，比如 String。</font>

（2）<font color=red>同时也避免了类的重复加载，因为 JVM中区分不同类，不仅仅是根据类名，相同的 class文件被不同的 ClassLoader加载就是不同的两个类。</font>
