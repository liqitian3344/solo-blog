title: MySQL InnoDB和MyISAM索引结构简析
date: '2019-12-11 18:16:37'
updated: '2019-12-12 11:36:37'
tags: [mysql, 索引]
permalink: /articles/2019/12/11/1576059397104.html
---
# B+树

我们这里关注B+树的两个特性：

1. 叶子节点包含数据data（data并不特指数据库中的某一行数据，也可以是某个数值，指针等）
2. 叶子节点均在同一层，且每个节点均可以直接找到上一个或者下一个节点（双向指针，比常规的B+树多了一个指向上一个的指针）
 ![image.png](https://img.hacpai.com/file/2019/12/image-494c257c.png)
# InnoDB 聚簇索引

聚簇索引：行数据与键值（主键）紧凑地存储在一起；

InnoDB中表现为：B+树叶子节点的data用于存放**行数据**（包含主键值、其他列数据、回滚指针、事务id等），物理上索引数据与行数据都放在同一个文件中（`.ibd`）

以用户表为例，`id`为主键，另外name存在索引`idx_name`：

```sql
CREATE TABLE `t_user` (
  `id` bigint,
  `name` varchar(10),
  `age` int,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
);

```

插入数据：

```sql
insert into t_user (id,`name`,age) values
(1,'n7',10),
(2,'n6',20),
(3,'n5',30),
(4,'n4',40),
(5,'n3',50),
(6,'n2',60),
(7,'n1',70)

```

聚簇索引对应的结构为：
![image.png](https://img.hacpai.com/file/2019/12/image-497beef3.png)
> 如果没有定义主键，InnoDB会选择一个非空的唯一索引代替。如果没有这样的索引，InnoDB会隐式定义一个主键（DB_ROW_ID）来作为聚簇索引。

> **最好避免使用随机的主键（比如UUID）**  
> InnoDB中磁盘管理的最小单位为页（InnoDB page，默认16KB），一页能存放的数据记录数量是有限的，根据B+树的特性，需要保证页内数据是按主键排序存储的。  
> 当主键随机**插入**时，如果新的记录可能需要插入之前记录的中间，导致需要强制移动之前的记录；如果需要插入一个已经满了的页中时，会导致**页分裂**（新建两个页并把原数据复制过去，成本很高）。

# InnoDB 二级索引

二级索引，或者叫非聚簇索引；与聚簇索引最大的不同是：B+树的**data存放的并不是行数据，而是主键值**；  
以上面用户表为例，当`select * from t_user where name='n1'`时，会先通过`idx_name`索引找到`n1`对应的主键的值（id=7），再通过主键值找到行数据 [7,n1,70] ，故称二级索引。  
![image.png](https://img.hacpai.com/file/2019/12/image-f0e6e51d.png)

> **覆盖索引**：当select的列的已经在二级索引的树中时，并不需要再通过主键值找到整行的数据即可返回。比如`select id,name from t_user where name='n1'` ，name和id均可在`idx_name`索引的**叶子节点**上，故不用主键回查聚簇索引了。像这种二级索引覆盖到所有查询列数据的情况叫覆盖索引。使用`explain`这个查询时可以看到`Extra`中包含`Using index`

# MyISAM 索引

与InnoDB不同，MyISAM并不使用聚簇索引，MyISAM的**索引数据和行数据是分开的**，物理上分别为`.myi`索引数据文件和`.myd`行数据文件（InnoDB 索引和行数据均在`.idb`文件中）

MyISAM中，主键索引和其他的一般索引在数据结构上并**没有什么区别**，B+树的**data**存放的均是**数据行地址**。

**id主键索引：**

 ![image.png](https://img.hacpai.com/file/2019/12/image-ecda0e72.png)

**普通索引：**
 ![image.png](https://img.hacpai.com/file/2019/12/image-05ff7066.png)

> 注：转录，言简意赅
附体验数据结构：https://www.cs.usfca.edu/~galles/visualization/
