title: MySQL-覆盖索引 、索引下推
date: '2019-12-07 22:36:17'
updated: '2019-12-13 17:22:47'
tags: [mysql, 索引]
permalink: /articles/2019/12/07/1575729377566.html
---
### 覆盖索引
1. 什么是覆盖索引（mysql不谈覆盖索引何谈sql优化） 
即从辅助索引中就可以得到查询的记录，而不需要查询聚集索引中的记录，称为‘覆盖索引’。使用覆盖索引的好吃是辅助索引不饱含整行记录的所有信息，故其大小要远小于聚集索引，因此可以减少大量的IO操作。  
  
2. 叙述  
我们常常说select的时候最好不要 select * ，而要写成select col1,col2....这种形式，但是如果在不使用覆盖索引的情况下， select * 和select col1,col2....的区别不大，select * 只不过多返回了一些字段，增加了一点网络传输上的消耗罢了，其实可以忽略不计。但是如果使用到了覆盖索引，那么他们之间的执行时间差距就大了。select col1 from table; select * from table;如果col1是一个辅助索引，那么Mysql只需要查询这个辅助索引就够了，而select * from table除了要查询辅助索引以外，还要再查一次聚集索引，这就就造成了额外的性能开销。数据量大的情况下，这两种查询的执行时间可能会相差十几倍。

覆盖索引带来的好处：
1. 索引条目通常远小于数据行大小，只需要读取索引，则mysql会极大地减少数据访问量。
2. 因为索引是按照列值顺序存储的，所以对于IO密集的范围查找会比随机从磁盘读取每一行数据的IO少很多。
3. innodb的聚簇索引，覆盖索引对innodb表特别有用。(innodb的二级索引在叶子节点中保存了行的主键值，所以如果二级主键能够覆盖查询，则可以避免对主键索引的二次查询)

> 注：
mysql的存储引擎Myisam要比innodb查询速度快的原因是，这两者的数据存储方式不一样，myisan是顺序存储，而innodb聚簇索引，myisam的索引指针指向的直接就是数据的的屋里地址，而innodb的索引指向的是主键，所以需要进行二次查找(sql用到索引时将会是行锁，锁的粒度小)，降低了查询的效率，因此innodb引入了索引覆盖技术，提高查找的效率。
关于Innodb，Myisam索引结构：[MySQL InnoDB和MyISAM索引结构简析](https://liqitian.com/articles/2019/12/11/1576059397104.html)


### 索引下推
对于user_table表，我们现在有（username,age）联合索引  
如果现在有一个需求，查出名称中以“张”开头且年龄小于等于10的用户信息，语句C如下："select * from user_table where username like '张%' and age > 10".  
语句C有两种执行可能：  
1. 根据（username,age）联合索引查询所有满足名称以“张”开头的索引，然后回表查询出相应的全行数据，然后再筛选出满足年龄小于等于10的用户数据。

 2. 根据（username,age）联合索引查询所有满足名称以“张”开头的索引，然后直接再筛选出年龄小于等于10的索引，之后再回表查询全行数据。

明显的，第二种方式需要回表查询的全行数据比较少，这就是mysql的索引下推。
mysql默认启用索引下推，我们也可以通过修改系统变量optimizer_switch的index_condition_pushdown标志来控制
```
show VARIABLES like '%optimizer_switch%';
SET optimizer_switch = 'index_condition_pushdown=off';
```
注意点：
1. innodb引擎的表，索引下推只能用于二级索引。

就像之前提到的，innodb的主键索引树叶子结点上保存的是全行数据，所以这个时候索引下推并不会起到减少查询全行数据的效果。

2. 索引下推一般可用于所求查询字段（select列）不是/不全是联合索引的字段，查询条件为多条件查询且查询条件子句（where/order by）字段全是联合索引。

假设表t有联合索引（a,b）,下面语句可以使用索引下推提高效率
select * from t where a > 2 and b > 10;

