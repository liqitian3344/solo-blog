title: My notes
date: '2019-09-03 11:35:55'
updated: '2019-09-29 17:00:12'
tags: [java, 概念]
permalink: /articles/2019/09/03/1567481755050.html
---
**ThreadLocal**：

提供了线程本地变量，它可以保证访问到的当前变量是属于当前线程的，每个线程都有一份该变量的副本，每个线程  的变量又都不同，而同一个线程在任何位置访问这个本地变量的结果都是一致的，当此线程生命周期结束时，所有的  线程本地示例都有会被GC，ThreadLocal相当于提供了一层线程隔离，将变量与线程绑定，Thread通常被声明为 private static类型。
```
  
ThreadLocal<Object> localThread = new ThreadLocal<>();  
  
localThread.set("1234");  
  
//*1234*  
  
System.out.print(localThread.get());
```
挺有用的，拿空间换时间

  

CAS（原子操作）：想到CAS我就想到了悲观锁，乐观锁的概念，悲观锁是mysql的机制是独占锁，排它锁，而synchronized也是一种独占锁，synchronized会导致其他未持有锁的线程阻塞，必须等待持有锁的线程释放锁资源，所谓乐观锁就是，每次不加锁而是假设没有冲突而去完成某项操作，如果因为冲突失败就重试，直到成功为止。而乐观锁用到的机制就是CAS。Compare And Set（或Compare And Swap），CAS是解决多线程并行情况下使用锁造成性能损耗的一种机制，CAS操作包含三个操作数——内存位置（V）、预期原值（A）、新值(B)。如果内存位置的值与预期原值相匹配，那么处理器会自动将该位置值更新为新值。否则，处理器不做任何操作。无论哪种情况，它都会在CAS指令之前返回该位置的值。CAS有效地说明了“我认为位置V应该包含值A；如果包含该值，则将B放到这个位置；否则，不要更改该位置，只告诉我这个位置现在的值即可。

  
@Scheduled（单线程问题）

默认所有的@Scheduled方法由单线程调度，不会同时执行的任务

例如：方法a和b，a的执行任务卡住了，即使时间到了b也不会执行，就是那么过分。

解决方法

```
@Configuration  
  
//定时任务调用一个线程池中的线程。  
  
public class ScheduleConfig implements SchedulingConfigurer {  
  
 @Override  
  
 public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {  
  
 //参数传入一个size为10的线程池  
  
scheduledTaskRegistrar.setScheduler(Executors.newScheduledThreadPool(10));  
 }  
}
```
  

间隙锁:

已知存在age为12，20，30，35，50的数据,session A 执行删除语句：delete from user_info WHERE age = 15；此时因为不存在age=15的数据，所以产生间隙锁，锁范围为[12，20]；所以在  sessionA事务未提交之前，不能对该为范围内的数据加锁，即不能进行update操作(包括 update，delete，insert);

session B执行insert操作：INSERT into user_info VALUES(REPLACE(UUID(),"-",""),"锁",18)，结果：Lock wait timeout exceeded; try restarting transaction

  查看mysql 特定表所有外键约束

select

```
TABLE_NAME,COLUMN_NAME,CONSTRAINT_NAME, REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME  
  
from INFORMATION_SCHEMA.KEY_COLUMN_USAGE  
  
where CONSTRAINT_SCHEMA ='senseguard' AND  
  
REFERENCED_TABLE_NAME = 'info_device_group';
```
git commit type介绍

type：用于说明commit的类别，规定为如下几种

feat：新增功能；

fix：修复bug；

docs：修改文档；

refactor：代码重构，未新增任何功能和修复任何bug；

build：改变构建流程，新增依赖库、工具等（例如webpack修改）；

style：仅仅修改了空格、缩进等，不改变代码逻辑；

perf：改善性能和体现的修改；

chore：非src和test的修改；

test：测试用例的修改；

ci：自动化流程配置修改；

revert：回滚到上一个版本；

scope：【可选】用于说明commit的影响范围

subject：commit的简要说明，尽量简短

