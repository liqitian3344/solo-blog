title: ShoppingMall-liqitian3344实战练习（B2C）
date: '2019-11-14 09:44:51'
updated: '2019-11-25 13:40:42'
tags: [sm]
permalink: /articles/2019/11/14/1573695891267.html
---
``1. * 1. 1. ### ### 项目地址：[ShoppingMall-liqitian3344](https://gitee.com/liqitian3344/ShoppingMall-liqitian3344 "ShoppingMall-liqitian3344")
### 准备redis环境
```
#跑了centos容器，预先开启7001-7006端口，不挂载任何目录
docker run --name redis-cluster-liqitian3344 --privileged=true -dit -p 7001:7001 -p 7002:7002 -p 7003:7003 -p 7004:7004 -p 7005:7005 -p 7006:7006 centos:latest

#进入容器中
docker exec -it redis-cluster-liqitian3344 bash

$ cd /root
$ wget http://download.redis.io/releases/redis-5.0.6.tar.gz
$ tar xzf redis-5.0.6.tar.gz
$ cd redis-5.0.6
$ make
```
####  准备集群节点
```
$ mkdir -p redis-cluster/redis-01
#把/root/redis-5.0.6/src/下的`redis-cli`,`redis-server`和/root/redis-5.0.6/redis.conf复制到redis-01下
$ cp /root/redis-5.0.6/src/redis-cli redis-01/
$ cp /root/redis-5.0.6/src/redis-server redis-01/
#简单修改redis-01/redis.conf
  1. 注释掉 `bind 127.0.0.1`
  2. `port`改为7001
  3. `cluster-enabled yes` 
  4. `protected-mode no`
  5. `daemonize yes`
# 将redis-01文件夹复制6份，依次为redis-02到redis-06，再依次修改各文件夹下redis.conf port为 7002-7006
```
创建启动脚本start-all.sh如下
```
cd redis-01 
./redis-server redis.conf &

cd ../redis-02 
./redis-server redis.conf &

cd ../redis-03 
./redis-server redis.conf &

cd ../redis-04 
./redis-server redis.conf &

cd ../redis-05
./redis-server redis.conf &

cd ../redis-06
./redis-server redis.conf 
```
启动集群：
`redis-cli --cluster create 127.0.0.1:7001 127.0.0.1:7002 127.0.0.1:7003 127.0.0.1:7004 127.0.0.1:7005 127.0.0.1:7006 --cluster-replicas 1`

创建关闭脚本stop-all.sh如下

```
cd redis-01 
./redis-cli -p 7001 shutdown &

cd ../redis-02 
./redis-cli -p 7002 shutdown &

cd ../redis-03 
./redis-cli -p 7003 shutdown & 

cd ../redis-04 
./redis-cli -p 7004 shutdown &

cd ../redis-05
./redis-cli -p 7005 shutdown &

cd ../redis-04 
./redis-cli -p 7006 shutdown 
```
连接任意节点:   `redis-cli -c -p 7006`查看集群信息
![image.png](https://img.hacpai.com/file/2019/11/image-2d0e221d.png)

再看下现在的主从状态
![image.png](https://img.hacpai.com/file/2019/11/image-7734aac7.png)
很明显可以看到主从状态，根据slots也可判别。
### Mysql主从复制搭建
1. docker pull mysql:5.7
2. docker run -p 4406:3306 --name mysql-master -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.7
3. docker run -p 5506:3306 --name mysql-slave -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.7

`docker ps`查看运行中容器
![image.png](https://img.hacpai.com/file/2019/11/image-68fbe365.png)

现在已经可以正常连接了
#### 配置Master
`docker exec -it mysql-master bash`进入容器
![image.png](https://img.hacpai.com/file/2019/11/image-2e17eb77.png)

`cd /etc/mysql`切换到/etc/mysql目录下，然后`vi my.cnf`对my.cnf进行编辑
此时会报出`bash: vi: command not found`，需要我们在docker容器内部自行安装vim。使用`apt-get update && apt-get install vim  -y`命令安装vim。

在my.cnf中添加如下配置：

```
[mysqld]  
## 最好保持唯一  
server-id=100  
## 开启二进制日志功能
log-bin=mysql-bin
```
下一步在Master数据库创建数据同步用户，授予用户 slave REPLICATION SLAVE（复制从机）权限和REPLICATION CLIENT（复制客户端）权限，用于在主从库之间同步数据。

`CREATE USER 'slave'@'%' IDENTIFIED BY '123456';`

`GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'slave'@'%';`
`flush privileges;`
`exit`退出容器，`docker restart mysql-master`重启容器。

## 配置Slave
在Slave配置文件my.cnf中添加如下配置：
```
[mysqld]  
## 设置server_id,注意要唯一  
server-id=101  
## 开启二进制日志功能，以备Slave作为其它Slave的Master时使用  
log-bin=mysql-slave-bin 
## relay_log配置中继日志  
relay_log=edu-mysql-relay-bin
```
重启容器。

#### 建立主从关系
进入mysql-master，登录mysql，输入`show master status;`回车。
![image.png](https://img.hacpai.com/file/2019/11/image-ba1fc0ce.png)

通过`docker inspect --format='{{.NetworkSettings.IPAddress}}' 容器名称|容器id`获取容器独立ip如下。
![image.png](https://img.hacpai.com/file/2019/11/image-919eb878.png)

进入mysql-slave，等上mysql执行
`change master to master_host='172.17.0.2', master_user='slave', master_password='123456', master_port=3306, master_log_file='mysql-bin.000001', master_log_pos= 154, master_connect_retry=30;`

**master_port**：Master的端口号，指的是容器的端口号

**master_user**：用于数据同步的用户

**master_password**：用于同步的用户的密码

**master_log_file**：指定 Slave 从哪个日志文件开始复制数据，即上文中提到的 File 字段的值

**master_log_pos**：从哪个 Position 开始读，即上文中提到的 Position 字段的值

**master_connect_retry**：如果连接失败，重试的时间间隔，单位是秒，默认是60秒

执行`show slave status\G`查看主从状态
![image.png](https://img.hacpai.com/file/2019/11/image-c9829fdf.png)
这是因为我们还没有开启主从复制，使用`start slave;`开启主从复制过程，然后再次查询主从同步状态`show slave status \G;`。
![image.png](https://img.hacpai.com/file/2019/11/image-8803b692.png)

### 利用shardingsphere分库分表读写分离
读写分离
application.properties 转yml（https://www.toyaml.com/index.html）
```
 <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-jdbc-spring-boot-starter</artifactId>
            <version>4.0.0-RC1</version>
        </dependency>
        
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid-spring-boot-starter</artifactId>
            <version>1.1.16</version>
        </dependency>

##yml配置
spring:
  shardingsphere:
    datasource:
        master:
            driver-class-name: com.mysql.jdbc.Driver
            password: 123456
            type: com.alibaba.druid.pool.DruidDataSource
            url: jdbc:mysql://localhost:4406/sm-users?useUnicode=true&characterEncoding=utf8&useSSL=false
            username: root
        names: master,slave0
        slave0:
            driver-class-name: com.mysql.jdbc.Driver
            password: 123456
            type: com.alibaba.druid.pool.DruidDataSource
            url: jdbc:mysql://localhost:5506/sm-users?useUnicode=true&characterEncoding=utf8&useSSL=false
            username: root
    masterslave:
        load-balance-algorithm-type: round_robin
        master-data-source-name: master
        name: ms
        slave-data-source-names: slave0
    props:
        sql:
            show: true
```
效果展示：
![image.png](https://img.hacpai.com/file/2019/11/image-129e4893.png)

分表+读写分离
```
#创建三张用户表
CREATE TABLE `user_0` (
                `id` bigint(21) NOT NULL AUTO_INCREMENT COMMENT '用户表id',
                `user_name` varchar(14) DEFAULT NULL COMMENT '用户名',
                `pass_word` varchar(14) DEFAULT NULL COMMENT '密码',
                `phone` varchar(11) NOT NULL COMMENT '用户手机号码',
                `user_secret` varchar(64) DEFAULT NULL COMMENT '用户密钥（系统自动生成）',
                `nick_name` varchar(8) DEFAULT NULL COMMENT '昵称',
                `balance` double(64,2) DEFAULT NULL COMMENT '余额',
                `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                `state` smallint(1) DEFAULT NULL COMMENT '0 未激活，1已激活',
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE KEY `user_name` (`user_name`)
                ) ENGINE=InnoDB AUTO_INCREMENT=1198271733091659778 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `user_1`(xxxx);
CREATE TABLE `user_2`(xxxx);
#yml:
spring:
  shardingsphere:
      datasource:
	#主库
          master0:
              driver-class-name: com.mysql.jdbc.Driver
              password: 123456
              type: com.alibaba.druid.pool.DruidDataSource
              url: jdbc:mysql://localhost:4406/sm-users?useUnicode=true&characterEncoding=utf8&useSSL=false
              username: root
          names: master0,slave0
	#从库
          slave0:
              driver-class-name: com.mysql.jdbc.Driver
              password: 123456
              type: com.alibaba.druid.pool.DruidDataSource
              url: jdbc:mysql://localhost:5506/sm-users?useUnicode=true&characterEncoding=utf8&useSSL=false
              username: root
	#读写分离策略
      masterslave:
          load-balance-algorithm-type: round_robin
          name: ms
      props:
          sql:
              show: true	#打印sql
      sharding:
          master-slave-rules:
              master0:
                  master-data-source-name: master0
                  slave-data-source-names: slave0
	#分表规则
          tables:
            user_:
              actual-data-nodes: master0.user_$->{0..2} #指定所需分的表
              table-strategy:
                inline:
                  sharding-column: id	#指定主键
                  algorithm-expression: user_$->{id % 3}	#分表规则为主键除以3取模
```
效果展示：
![image.png](https://img.hacpai.com/file/2019/11/image-e45fa85c.png)

### 设计相关
#### 优惠券设计
优惠券是一套规则的组合，创建优惠券是优惠券系统设计的第一步，主要有以下几部分组成：基本信息、优惠类型、使用范围、有效期等。

这里需要考虑到优惠券是否可叠加使用，每人限领张数、是否和其他促销同时使用（优惠优先级）、使用规则等。
2. 优惠类型
主要有满减、立减、折扣券或优惠码。满减、立减、折扣券。

有效期一般有两种：

一种是固定的有效期，设定一个时间段；

另一种是设定一个有效数，比如：30天，一般是从领取之日起30天内有效。
这里我们一贯采用第二种。

![image.png](https://img.hacpai.com/file/2019/11/image-0143e662.png)


#### 活动设计
1. 基本信息
包括活动名称、活动时间、活动图片、活动状态和活动规则等。
活动状态可分为未开始、进行中、已结束。
![image.png](https://img.hacpai.com/file/2019/11/image-9de617c4.png)

#### 优惠券退还问题
用户下单未支付，取消订单，优惠券可退还；

商家在订单未完成的情况下，发起退款操作，优惠券可退还；

用户下单支付后，申请退款，优惠不可退还。

